import matplotlib
matplotlib.use("Agg")  # 无 GUI 后端，方便 Flask 服务器环境

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from sklearn.tree import DecisionTreeClassifier
from matplotlib.font_manager import FontProperties

# ===== 中文字体设置（Linux/Win 通用兜底） =====
font_path = '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc'
if not os.path.exists(font_path):
    font_path = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
font_prop = FontProperties(fname=font_path)
matplotlib.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# 获取当前脚本所在目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ===== 1. 模型训练（特征 = 真实温度℃ + 干旱程度等级）=====
train_data = [
    [20, 2.0], [22, 2.0], [18, 3.0],
    [25, 4.0], [30, 3.0], [15, 3.0],
    [22, 5.0], [21, 1.0],
]
train_labels = ['Yes','Yes','Yes','Yes','No','No','No','No']
model = DecisionTreeClassifier()
model.fit(train_data, train_labels)

# ===== 2. 工具函数 =====
def date_to_day_of_year(date_str: str) -> int:
    """'YYYY-MM-DD' → 一年中的第几天"""
    return datetime.strptime(date_str, "%Y-%m-%d").timetuple().tm_yday

def is_within_time_range(day_of_year: int, variety: str) -> bool:
    """
    按品种的经验播期判断（按你之前的设定保持不变）
    """
    ranges = {'A': (134, 150), 'B': (136, 155), 'C': (141, 161)}
    s, e = ranges.get(variety, (110, 130))
    return s <= day_of_year <= e

def is_within_time_range_area(day_of_year: int, variety_area: str) -> bool:
    """
    按基地经验播期判断
    """
    ranges = {
        'jiangxingzhuang': (148, 152),
        'gaojiajian':      (138, 142),
        'yuecha':          (140, 141),
        'lijiasi':         (140, 141),
        'houjiagou':       (150, 156),
        'sigou':           (138, 142),
        'yangjiagou':      (145, 146),
        'fengliangu':      (139, 141),
    }
    s, e = ranges.get(variety_area, (120, 170))
    return s <= day_of_year <= e

# ===== 3. 寻找最佳播种窗口（用真实温度 temp + 干旱等级 rainfall）=====
def find_best_sowing_window(daily_data, variety, variety_area, year=2025):
    """
    模型预测 + 经验期：
    1) 窗口平均温度 + 最小（或代表性）干旱等级必须被模型预测为 Yes
    2) 窗口内每一天 (真实温度, 干旱等级) 也必须逐日预测为 Yes
    3) 中心日要落在品种 & 基地的经验播期内更优
    """
    reasons = set()
    best_outside = None

    # 尝试 3 日窗、4 日窗
    for window_size in (3, 4):
        for i in range(len(daily_data) - window_size + 1):
            win = daily_data[i:i + window_size]
            dates     = [d["date"] for d in win]
            temps     = [float(d["temp"]) for d in win]
            drylvls   = [float(d["rainfall"]) for d in win]

            # 1) 整体窗口判断
            avg_temp = sum(temps) / window_size
            min_dry  = min(drylvls)
            doy      = date_to_day_of_year(dates[window_size // 2])

            if model.predict([[avg_temp, min_dry]])[0] != 'Yes':
                reasons.add("模型判断不适宜播种（整体平均不通过）")
                continue

            # 2) 逐日判断
            day_results = [model.predict([[t, r]])[0] for t, r in zip(temps, drylvls)]
            if not all(res == 'Yes' for res in day_results):
                reasons.add("窗口内存在单日不适宜播种")
                continue

            # 3) 经验期判断
            within = is_within_time_range(doy, variety) and is_within_time_range_area(doy, variety_area)
            cand = {"start": dates[0], "end": dates[-1], "within_experience_range": within}

            if within:
                return cand
            if best_outside is None:
                best_outside = cand

    return best_outside or {"cannot_sow_reasons": sorted(reasons)}

# ===== 4. 趋势图（左轴：真实温度；右轴：墒情等级）=====
def render_summary_graph_with_window(daily_data, result, variety, output_path):
    """
    趋势图：
      - x：日期
      - 左轴：真实温度曲线（℃）
      - 右轴：墒情（干旱等级 1~5）柱状
      - 背景用色块标出推荐播种窗口
    """
    dates     = [d['date'] for d in daily_data]
    temps     = [float(d['temp']) for d in daily_data]
    drylvls   = [float(d['rainfall']) for d in daily_data]
    x = np.arange(len(dates))

    # 调整宽度和高度
    fig, ax1 = plt.subplots(figsize=(18, 4))  # 宽度增加，高度减少
    ax2 = ax1.twinx()

    # 右轴：墒情柱状图
    ax2.bar(x - 0.2, drylvls, width=0.4, label='墒情等级', color='#5DADE2', zorder=1)
    ax2.set_ylabel('墒情等级')

    # 左轴：温度曲线
    ax1.plot(x, temps, color='orange', label='气温(°C)', linewidth=2, zorder=3)
    ax1.set_ylabel('气温(°C)')

    # X 轴日期
    ax1.set_xticks(x)
    ax1.set_xticklabels(
        [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates],
        rotation=45, ha='right'
    )

    # 标注推荐播种窗口
    if 'start' in result and 'end' in result and result.get('start') and result.get('end'):
        if result['start'] in dates and result['end'] in dates:
            si = dates.index(result['start'])
            ei = dates.index(result['end'])
            ax1.axvspan(
                si - 0.5, ei + 0.5,
                color='#2874A6', alpha=0.3, zorder=5, label='推荐播种窗口'
            )

    # 图例（先墒情，再温度 & 推荐窗口），放右侧外面
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(
        h2 + h1, l2 + l1,
        loc='upper left',
        bbox_to_anchor=(1.05, 1),  # ← 图例右移
        borderaxespad=0.
    )

    plt.tight_layout(rect=(0, 0, 0.78, 1))  # ← 主图右边再留更宽的空间

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, bbox_inches='tight')
    plt.close()


# ===== 5. 温度双向条形图（基准 15°C）=====
def render_temp_mirror_bar(daily_data, variety, output_path, title=""):
    """
    温度双向条形图（真实刻度均匀版）：
      - 品种 A → 基准 15°C
      - 品种 B → 基准 16°C
      - 品种 C → 基准 17°C
      - y 轴刻度显示真实温度，且基准线所在刻度一定存在、均匀分布
    """
    from datetime import datetime
    import matplotlib.pyplot as plt
    import os
    import numpy as np

    # -------- 1) 品种基准 --------
    baseline_map = {"A": 15.0, "B": 16.0, "C": 17.0}
    baseline = baseline_map.get(variety, 15.0)

    # -------- 2) 数据 --------
    dates = [d["date"] for d in daily_data]
    temps = [float(d.get("temp", 0.0)) for d in daily_data]
    rel_vals = [t - baseline for t in temps]   # 以 baseline 为0的相对值

    x = list(range(len(dates)))
    xlabels = [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates]

    fig, ax = plt.subplots(figsize=(12, 5))

    # -------- 3) 双向条形图 --------
    ax.bar(x, rel_vals, color="#E67E22", width=0.4)  # 设置柱子宽度为0.4，使其与趋势图一致
    ax.axhline(0, color="black", linewidth=1)   # 基准线（15/16/17℃）
    ax.set_ylabel("温度 (°C)")

    # X 轴
    ax.set_xticks(x)
    ax.set_xticklabels(xlabels, rotation=45, ha="right", fontsize=12)  # 增加日期标签的字体大小

    # 调整Y轴刻度的字体大小
    ax.tick_params(axis='y', labelsize=12)  # 温度图 Y 轴字体大小

    # 柱子标注真实温度
    for i, (rv, t) in enumerate(zip(rel_vals, temps)):
        va = "bottom" if rv >= 0 else "top"
        ax.text(i, rv, f"{t:.1f}", ha="center", va=va, fontsize=9)

    # -------- 4) 均匀真实刻度 & 保证基准刻度存在 --------
    if temps:
        # 与基准温度的最大偏差
        max_dev = max(abs(t - baseline) for t in temps)
        # 给一点冗余，让图不挤
        dev = max_dev + 1

        # 真实温度的刻度范围：围绕 baseline 对称
        real_min = baseline - dev
        real_max = baseline + dev

        # 生成 5 个“真实温度刻度”，baseline 会在中间那个
        real_ticks = np.linspace(real_min, real_max, num=5)

        # 转成相对刻度（画在 y 轴上的位置）
        relative_ticks = [rt - baseline for rt in real_ticks]

        ax.set_yticks(relative_ticks)
        ax.set_yticklabels([f"{rt:.0f}" for rt in real_ticks])

        # Y 轴显示范围再放大一点
        span = max(abs(relative_ticks[0]), abs(relative_ticks[-1])) * 1.1
        ax.set_ylim(-span, span)
    else:
        # 没数据时兜底
        ax.set_ylim(-1, 1)
        ax.set_yticks([0])
        ax.set_yticklabels([f"{baseline:.0f}"])

    # 标题
    if title:
        ax.set_title(title)

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()







# ===== 6. 墒情双向条形图（基准 2）=====
def render_moisture_mirror_bar(daily_data, output_path, title=""):
    """
    墒情双向条形图：
      - y 轴显示真实墒情等级(1~5)
      - 基准线固定为 2
      - 上半轴展示到最大墒情
      - 下半轴只展示到 1（更短）
    """
    import matplotlib.pyplot as plt
    from datetime import datetime
    import os

    # -------- 数据 --------
    dates = [d["date"] for d in daily_data]
    moistures = [float(d.get("rainfall", 0.0)) for d in daily_data]

    baseline = 2.0
    rel_vals = [m - baseline for m in moistures]

    x = list(range(len(dates)))
    xlabels = [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates]

    fig, ax = plt.subplots(figsize=(12, 5))

    # -------- 双向条形（相对 2） --------
    ax.bar(x, rel_vals, color="#3498DB", width=0.4)  # 设置柱子宽度为0.4，使其与趋势图一致

    # 基线
    ax.axhline(0, color="black", linewidth=1)
    ax.set_ylabel("墒情等级")

    # X 轴
    ax.set_xticks(x)
    ax.set_xticklabels(xlabels, rotation=45, ha="right", fontsize=12)  # 增加日期标签的字体大小

    # 调整Y轴刻度的字体大小
    ax.tick_params(axis='y', labelsize=12)  # 墒情图 Y 轴字体大小

    # -------- 上半轴与下半轴范围 --------
    m_min = min(moistures)
    m_max = max(moistures)

    # 上半轴最大高度：最大墒情值 → 相对值 (m_max - 2)
    upper_span = max(1, m_max - baseline)

    # 下半轴缩短：只保留到等级 1（即 1 → 相对值 -1）
    lower_span = 1  # 下半轴只显示 1 级（短）

    ax.set_ylim(-lower_span * 1.2, upper_span * 1.2)

    # -------- 真实刻度映射 --------
    real_ticks = []
    real_labels = []

    # 下半轴刻度只有“1”
    real_ticks.append(1 - baseline)
    real_labels.append("1")

    # 基准线 2
    real_ticks.append(0)
    real_labels.append("2")

    # 上半轴刻度：3,4,5（自动）
    for lv in range(3, int(m_max) + 1):
        real_ticks.append(lv - baseline)
        real_labels.append(str(lv))

    ax.set_yticks(real_ticks)
    ax.set_yticklabels(real_labels)

    # -------- 柱子上显示真实墒情等级 --------
    for i, (rv, m) in enumerate(zip(rel_vals, moistures)):
        va = "bottom" if rv >= 0 else "top"
        ax.text(i, rv, f"{m:.1f}", ha="center", va=va, fontsize=9)

    if title:
        ax.set_title(title)

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()


