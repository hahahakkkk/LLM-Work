import matplotlib
matplotlib.use("Agg")  # 无 GUI 后端，适合 Flask

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from sklearn.tree import DecisionTreeClassifier
from matplotlib.font_manager import FontProperties

# ===== 全局字体配置（使用项目内 Noto Sans CJK SC）=====
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_PATH = os.path.join(BASE_DIR, "fonts", "NotoSansCJKsc-Regular.otf")

if os.path.exists(FONT_PATH):
    try:
        FONT_PROP = FontProperties(fname=FONT_PATH)
        # 辅助设置 rcParams（非必需，但有助于部分组件）
        plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
    except Exception as e:
        print(f"⚠️ 字体加载失败: {e}")
        FONT_PROP = None
else:
    print(f"⚠️ 字体文件不存在: {FONT_PATH}")
    FONT_PROP = None


def _get_window_x_range(dates, result):
    if not result.get("start") or not result.get("end"):
        return None, None
    if result["start"] not in dates or result["end"] not in dates:
        return None, None

    si = dates.index(result["start"])
    ei = dates.index(result["end"])
    return si - 0.5, ei + 0.5


# ===== 1. 模型训练 =====
train_data = [
    [20, 2.0], [22, 2.0], [18, 3.0],
    [25, 4.0], [30, 3.0], [15, 3.0],
    [22, 5.0], [21, 1.0],
]
train_labels = ['Yes','Yes','Yes','Yes','No','No','No','No']
model = DecisionTreeClassifier()
model.fit(train_data, train_labels)


# ===== 2. 工具函数 =====
def date_to_day_of_year(date_str: str) -> int:
    return datetime.strptime(date_str, "%Y-%m-%d").timetuple().tm_yday

def is_within_time_range(day_of_year: int, variety: str) -> bool:
    ranges = {'A': (134, 150), 'B': (136, 155), 'C': (141, 161)}
    s, e = ranges.get(variety, (110, 130))
    return s <= day_of_year <= e

def is_within_time_range_area(day_of_year: int, variety_area: str) -> bool:
    ranges = {
        'jiangxingzhuang': (148, 152),
        'gaojiajian':      (138, 142),
        'yuecha':          (140, 141),
        'lijiasi':         (140, 141),
        'houjiagou':       (150, 156),
        'sigou':           (138, 142),
        'yangjiagou':      (145, 146),
        'fengliangu':      (139, 141),
    }
    s, e = ranges.get(variety_area, (120, 170))
    return s <= day_of_year <= e


# ===== 突出显示窗口 =====
def highlight_window_style1(ax, x0, x1, label="推荐播种期"):
    ymin, ymax = ax.get_ylim()
    n = 100
    xs = np.linspace(x0, x1, n)

    start_color = np.array([1.0, 0.8, 0.9])
    end_color   = np.array([1.0, 0.3, 0.7])

    for i in range(n - 1):
        t = i / (n - 1)
        c = start_color * (1 - t) + end_color * t
        ax.axvspan(xs[i], xs[i+1], ymin=0, ymax=1, color=c, alpha=0.4, zorder=2)

    ax.text(
        (x0 + x1) / 2,
        ymax,
        label,
        ha="center",
        va="bottom",
        fontsize=12,
        color="#C2185B",
        fontweight="bold",
        zorder=4,
        fontproperties=FONT_PROP if FONT_PROP else None
    )


# ===== 3. 寻找最佳播种窗口 =====
def find_best_sowing_window(daily_data, variety, variety_area, year=2025):
    reasons = set()
    best_outside = None

    for window_size in (3, 4):
        for i in range(len(daily_data) - window_size + 1):
            win = daily_data[i:i + window_size]
            dates     = [d["date"] for d in win]
            temps     = [float(d["temp"]) for d in win]
            drylvls   = [float(d["rainfall"]) for d in win]

            avg_temp = sum(temps) / window_size
            min_dry  = min(drylvls)
            doy      = date_to_day_of_year(dates[window_size // 2])

            if model.predict([[avg_temp, min_dry]])[0] != 'Yes':
                reasons.add("模型判断不适宜播种（整体平均不通过）")
                continue

            day_results = [model.predict([[t, r]])[0] for t, r in zip(temps, drylvls)]
            if not all(res == 'Yes' for res in day_results):
                reasons.add("窗口内存在单日不适宜播种")
                continue

            within = is_within_time_range(doy, variety) and is_within_time_range_area(doy, variety_area)
            cand = {"start": dates[0], "end": dates[-1], "within_experience_range": within}

            if within:
                return cand
            if best_outside is None:
                best_outside = cand

    return best_outside or {"cannot_sow_reasons": sorted(reasons)}


# ===== 4. 趋势图（双轴 + 推荐窗口）=====
def render_summary_graph_with_window(daily_data, result, variety, output_path):
    dates     = [d['date'] for d in daily_data]
    temps     = [float(d['temp']) for d in daily_data]
    drylvls   = [float(d['rainfall']) for d in daily_data]
    x = np.arange(len(dates))

    fig, ax1 = plt.subplots(figsize=(18, 4))
    ax2 = ax1.twinx()

    ax2.bar(x - 0.2, drylvls, width=0.4, label='墒情等级', color='#5DADE2', zorder=1)
    ax2.set_ylabel('墒情等级', fontproperties=FONT_PROP if FONT_PROP else None)

    ax1.plot(x, temps, color='orange', label='气温(°C)', linewidth=2, zorder=3)
    ax1.set_ylabel('气温(°C)', fontproperties=FONT_PROP if FONT_PROP else None)

    ax1.set_xticks(x)
    ax1.set_xticklabels(
        [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates],
        rotation=45, ha='right',
        fontproperties=FONT_PROP if FONT_PROP else None
    )

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(
        h2 + h1, l2 + l1,
        loc='upper left',
        bbox_to_anchor=(1.05, 1),
        borderaxespad=0.
    )

    x0, x1 = _get_window_x_range(dates, result)
    if x0 is not None:
        highlight_window_style1(ax1, x0, x1)

    plt.tight_layout(rect=(0, 0, 0.78, 1))
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, bbox_inches='tight')
    plt.close()


# ===== 5. 温度条形图 =====
def render_temp_mirror_bar(daily_data, output_path, title="温度条形图"):
    from datetime import datetime

    dates = [d["date"] for d in daily_data]
    temps = [float(d.get("temp", 0.0)) for d in daily_data]

    x = list(range(len(dates)))
    xlabels = [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates]

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.bar(x, temps, width=0.4, color="#E67E22")

    ax.set_xticks(x)
    ax.set_xticklabels(xlabels, rotation=45, fontproperties=FONT_PROP if FONT_PROP else None)
    ax.set_ylabel("温度 (°C)", fontproperties=FONT_PROP if FONT_PROP else None)
    ax.set_title(title, pad=20, fontproperties=FONT_PROP if FONT_PROP else None)
    ax.set_ylim(bottom=0)

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)


# ===== 6. 墒情条形图 =====
def render_moisture_mirror_bar(daily_data, output_path, title="墒情条形图"):
    from datetime import datetime

    dates = [d["date"] for d in daily_data]
    moistures = [float(d.get("rainfall", 0.0)) for d in daily_data]

    x = list(range(len(dates)))
    xlabels = [datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates]

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.bar(x, moistures, width=0.4, color="#3498DB")

    ax.set_xticks(x)
    ax.set_xticklabels(xlabels, rotation=45, fontproperties=FONT_PROP if FONT_PROP else None)
    ax.set_ylabel("墒情等级", fontproperties=FONT_PROP if FONT_PROP else None)
    ax.set_title(title, fontproperties=FONT_PROP if FONT_PROP else None)

    fig.tight_layout()
    fig.savefig(output_path)
    plt.close(fig)