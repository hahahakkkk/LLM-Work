from flask import Flask, request, jsonify
import time, requests, jwt, certifi

API_HOST = "https://kt6936vmq8.re.qweatherapi.com"
KEY_ID = "K6WKR62G22"
PROJECT_ID = "4K85XWKCXA"
PRIVATE_KEY = """-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEICNiU3AWu7tDYyQx4Jb73XTtZ8o1RT22htdESuOwAqfR
-----END PRIVATE KEY-----"""

app = Flask(__name__, static_folder="static", static_url_path="")

def make_jwt(ttl_seconds=900):
    now = int(time.time())
    payload = {"sub": PROJECT_ID, "iat": now - 30, "exp": now - 30 + ttl_seconds}
    headers = {"kid": KEY_ID, "alg": "EdDSA"}
    return jwt.encode(payload, PRIVATE_KEY, algorithm="EdDSA", headers=headers)

def qweather_get(path, params):
    token = make_jwt()
    r = requests.get(
        API_HOST + path,
        headers={"Authorization": f"Bearer {token}", "Accept-Encoding": "gzip"},
        params=params,
        timeout=15,
        verify=certifi.where()
    )
    r.raise_for_status()
    return r.json()

def _to_float(v, default=None):
    if v in (None, ""):
        return default
    try:
        return float(v)
    except Exception:
        return default

def slim_daily(d):
    # 返回：[{date, tempMax, tempMin, precip}]
    out = []
    for x in d.get("daily", []):
        out.append({
            "date":    x["fxDate"],
            "tempMax": _to_float(x.get("tempMax")),
            "tempMin": _to_float(x.get("tempMin")),
            "precip":  _to_float(x.get("precip"), 0.0),
        })
    return out

def slim_daily_avg(d):
    # 返回：[{date, tempAvg, precip}]
    out = []
    for x in d.get("daily", []):
        tmax = _to_float(x.get("tempMax"))
        tmin = _to_float(x.get("tempMin"))
        tavg = round((tmax + tmin) / 2.0, 2) if (tmax is not None and tmin is not None) else None
        out.append({
            "date":    x["fxDate"],
            "tempAvg": tavg,
            "precip":  _to_float(x.get("precip"), 0.0),
        })
    return out

def slim_hourly(h):
    # 返回：[{time, temp, precip}]
    out = []
    for x in h.get("hourly", []):
        out.append({
            "time":   x["fxTime"],
            "temp":   _to_float(x.get("temp")),
            "precip": _to_float(x.get("precip"), 0.0),
        })
    return out

@app.get("/detect")
def forecast():
    location = request.args.get("location", "101110408")
    days  = request.args.get("days",  "15d")
    hours = request.args.get("hours", "24h")
    lang  = request.args.get("lang",  "zh")
    unit  = request.args.get("unit",  "m")

    # 先拿原始数据
    d = qweather_get(f"/v7/weather/{days}",  {"location": location, "lang": lang, "unit": unit})
    h = qweather_get(f"/v7/weather/{hours}", {"location": location, "lang": lang, "unit": unit})

    # 返回同时包含 daily（原始精简）和 dailyAvg（平均温）
    return jsonify({
        "dailyAvg":   slim_daily_avg(d),   # 平均温 + 降雨（给前端画“平均温”）
        "daily":      slim_daily(d),       # 兼容保留；前端不用也没关系
        "hourly":     slim_hourly(h),
        "generatedAt": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "location":   location
    })

@app.get("/api/ping")
def ping():
    return {"ok": True, "ts": time.strftime("%Y-%m-%dT%H:%M:%S")}

@app.get("/")
def index():
    return app.send_static_file("index.html")

if __name__ == "__main__":
    app.run("0.0.0.0", 25566, debug=False)

