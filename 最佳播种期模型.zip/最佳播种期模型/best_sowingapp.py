# app.py —— 非5/6月切换到内置数据 + 动态干旱规则 + QWeather简易鉴权（?key=）
import os, traceback, logging
import requests
import pandas as pd
import pymysql
from datetime import datetime
from flask import Flask, request, send_file, jsonify

# ====== 你的模型函数（保持不变） ======
from sowing_model import (
    find_best_sowing_window,
    render_summary_graph_with_window,
    render_month_calendar,
    render_warning_image,
    merge_custom_layout,
    render_temp_rain_line,
)

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUTS = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUTS, exist_ok=True)

# ---------- 全局异常输出 ----------
app.config["PROPAGATE_EXCEPTIONS"] = True
@app.errorhandler(Exception)
def _handle_any_error(e):
    logging.error("Unhandled error:", exc_info=True)
    print("".join(traceback.format_exception(type(e), e, e.__traceback__)))
    return jsonify(error=str(e)), 500

# ---------- MySQL（仅 /plot/all 用） ----------
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "123456",     # ← 按需修改
    "database": "best_sowing",
    "charset": "utf8mb4",
}
AREA_TABLE_MAP = {
    "jiangxingzhuang": "weather_jiangxingzhuang",
    "gaojiajian":      "weather_gaojiajian",
    "yuecha":          "weather_yuecha",
    "lijiasi":         "weather_lijiasi",
    "houjiagou":       "weather_houjiagou",
    "sigou":           "weather_sigou",
    "yangjiagou":      "weather_yangjiagou",
    "fengliangu":      "weather_fengliangu",
}
def load_data_from_db(area: str, start_date: str = None, end_date: str = None):
    table = AREA_TABLE_MAP.get(area)
    if not table:
        raise ValueError(f"未知地区: {area}")
    conn = pymysql.connect(**DB_CONFIG)
    try:
        if start_date and end_date:
            q = f"""
                SELECT date, temp, rainfall
                FROM {table}
                WHERE date BETWEEN '{start_date}' AND '{end_date}'
                ORDER BY date ASC;
            """
        else:
            q = f"SELECT date, temp, rainfall FROM {table} ORDER BY date ASC;"
        df = pd.read_sql(q, conn)
    finally:
        conn.close()
    daily = []
    for _, row in df.iterrows():
        daily.append({
            "date": str(row["date"]),
            "temp": float(row["temp"]),
            "rainfall": float(row["rainfall"]),
        })
    return daily

# ---------- QWeather 简单鉴权 ----------
QWEATHER_HOST = os.getenv("QWEATHER_HOST", "devapi.qweather.com").strip()
QWEATHER_KEY  = os.getenv("QWEATHER_KEY", "").strip()
QWEATHER_15D_URL = f"https://{QWEATHER_HOST}/v7/weather/15d"
QWEATHER_7D_URL  = f"https://{QWEATHER_HOST}/v7/weather/7d"
DEFAULT_LOCATION_ID = "101110408"

def precip_to_dryness_level(precip_mm: float) -> int:
    if precip_mm >= 10: return 1
    if precip_mm >= 5:  return 2
    if precip_mm >= 2:  return 3
    if precip_mm >= 0.1:return 4
    return 5

def _call_qweather(url: str, loc: str, key: str):
    r = requests.get(url, params={"location": loc, "key": key}, timeout=10)
    print("QWeather URL:", r.url, "HTTP:", r.status_code)
    try:
        js = r.json()
    except Exception:
        js = {}
    return r.status_code, js, r.text

def fetch_future_from_qweather():
    if not QWEATHER_KEY:
        raise RuntimeError("未配置 QWEATHER_KEY（环境变量或在代码中写入）")
    loc = DEFAULT_LOCATION_ID
    code1, js1, text1 = _call_qweather(QWEATHER_15D_URL, loc, QWEATHER_KEY)
    if code1 == 200 and js1.get("code") == "200" and "daily" in js1:
        raw = js1["daily"]
    else:
        code2, js2, text2 = _call_qweather(QWEATHER_7D_URL, loc, QWEATHER_KEY)
        if not (code2 == 200 and js2.get("code") == "200" and "daily" in js2):
            raise RuntimeError(f"QWeather失败：15d {code1} {text1[:150]} | 7d {code2} {text2[:150]}")
        raw = js2["daily"]
    out = []
    for d in raw:
        tmax, tmin = d.get("tempMax"), d.get("tempMin")
        if tmax is None and tmin is None:
            continue
        tmax = float(tmax) if tmax is not None else None
        tmin = float(tmin) if tmin is not None else None
        t_avg = (tmax + tmin)/2.0 if (tmax is not None and tmin is not None) else (tmax or tmin)
        precip = float(d.get("precip") or 0.0)
        dryness = precip_to_dryness_level(precip)
        out.append({
            "date": d.get("fxDate"),
            "temp": float(t_avg),
            "rainfall": float(dryness),
            "precip_mm": precip
        })
    return out

# ---------- 指定的“非 5/6 月”数据 ----------
FORCED_DAILY = [
    {"date": "2025-05-10", "temp": 27.5, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-11", "temp": 28.2, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-12", "temp": 26.0, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-13", "temp": 27.8, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-14", "temp": 27.3, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-15", "temp": 20.1, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-16", "temp": 22.4, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-17", "temp": 25.0, "precip_mm": 3.0,  "rainfall": 2},
    {"date": "2025-05-18", "temp": 24.7, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-19", "temp": 26.9, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-20", "temp": 28.5, "precip_mm": 0.0,  "rainfall": 0},
    {"date": "2025-05-21", "temp": 23.2, "precip_mm": 8.0,  "rainfall": 3},
    {"date": "2025-05-22", "temp": 20.0, "precip_mm": 2.6,  "rainfall": 2},
    {"date": "2025-05-23", "temp": 21.8, "precip_mm": 7.0,  "rainfall": 3},
    {"date": "2025-05-24", "temp": 20.3, "precip_mm": 8.0,  "rainfall": 3},
]

def should_force_offseason() -> bool:
    m = datetime.now().month
    return m not in (5, 6)

# ---------- 动态干旱规则 ----------
def apply_dynamic_drought(daily_data):
    drought = 3
    no_rain_count = 0
    for d in daily_data:
        precip_mm = float(d.get("precip_mm")) if d.get("precip_mm") is not None else None
        rained = (precip_mm is not None and precip_mm > 0) or (precip_mm is None and float(d.get("rainfall", 0)) > 0)
        if rained:
            drought = 1
            no_rain_count = 0
        else:
            no_rain_count += 1
            if no_rain_count >= 3:
                drought = min(5, drought + 1)
                no_rain_count = 0
        d["rainfall"] = float(drought)

# ---------- 健康检查 ----------
@app.route("/")
def index():
    return jsonify({
        "ok": True,
        "message": "best_sowing API (real-temp) + dynamic drought + offseason fallback",
        "host": QWEATHER_HOST,
        "location_id": DEFAULT_LOCATION_ID,
        "offseason_forced": should_force_offseason()
    })

# ========== 所有 POST 接口改为 @app.route(..., methods=["POST"]) ==========

@app.route("/plot/all", methods=["POST"])
def plot_all():
    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")
    start_date = data.get("start_date")
    end_date   = data.get("end_date")
    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = [dict(x) for x in FORCED_DAILY]
    else:
        daily = load_data_from_db(area, start_date, end_date)
        if not daily:
            return jsonify(error="数据库中该日期范围无数据"), 404

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path    = os.path.join(OUTPUTS, "trend.png")
    calendar_path = os.path.join(OUTPUTS, "calendar.png")
    warning_path  = os.path.join(OUTPUTS, "warning.png")
    all_path      = os.path.join(OUTPUTS, "all_in_one.png")

    render_summary_graph_with_window(daily, best, variety, trend_path)
    render_month_calendar(daily, best, calendar_path)
    render_warning_image(daily, best, variety, warning_path)
    merge_custom_layout(trend_path, calendar_path, warning_path, all_path)
    print(f"输出图片已保存：{all_path}")
    return send_file(all_path, mimetype="image/png")


@app.route("/plot/forecast", methods=["POST"])
def plot_forecast():
    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")
    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = [dict(x) for x in FORCED_DAILY]
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path    = os.path.join(OUTPUTS, "trend.png")
    calendar_path = os.path.join(OUTPUTS, "calendar.png")
    warning_path  = os.path.join(OUTPUTS, "warning.png")
    all_path      = os.path.join(OUTPUTS, "all_in_one.png")

    render_summary_graph_with_window(daily, best, variety, trend_path)
    render_month_calendar(daily, best, calendar_path)
    render_warning_image(daily, best, variety, warning_path)

    temp_rain_path = os.path.join(OUTPUTS, "temp_rain_line.png")
    render_temp_rain_line(daily, temp_rain_path, title="温度与降雨量")
    merge_custom_layout(trend_path, calendar_path, warning_path, all_path)
    print(f"输出图片已保存：{trend_path}")

    import base64
    with open(trend_path, "rb") as f:
        img64 = base64.b64encode(f.read()).decode()

    return jsonify({
        "start": best.get("start"),
        "end": best.get("end"),
        "image_base64": img64
    })


@app.route("/plot/temp_rain", methods=["POST"])
def plot_temp_rain():
    data = request.get_json(force=True) or {}
    area = data.get("variety_area") or data.get("area")
    if not area:
        return jsonify(error="请提供基地 variety_area"), 400

    if should_force_offseason():
        daily = [dict(x) for x in FORCED_DAILY]
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    temp_rain_path = os.path.join(OUTPUTS, "temp_rain_line.png")
    render_temp_rain_line(daily, temp_rain_path, title="温度与降雨量")
    return send_file(temp_rain_path, mimetype="image/png")


@app.route("/plot/forecast_zip_json", methods=["POST"])
def plot_forecast_zip_json():
    from io import BytesIO
    import zipfile, json, base64
    from datetime import datetime

    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")
    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    VARIETY_MAP = {
        "A": "米谷1号",
        "B": "米谷2号",
        "C": "晋谷21号"
    }
    cn_variety = VARIETY_MAP.get(variety, variety)

    if should_force_offseason():
        daily = [dict(x) for x in FORCED_DAILY]
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path    = os.path.join(OUTPUTS, "trend.png")
    calendar_path = os.path.join(OUTPUTS, "calendar.png")
    warning_path  = os.path.join(OUTPUTS, "warning.png")
    all_path      = os.path.join(OUTPUTS, "all_in_one.png")

    render_summary_graph_with_window(daily, best, variety, trend_path)
    render_month_calendar(daily, best, calendar_path)
    render_warning_image(daily, best, variety, warning_path)

    temp_rain_path = os.path.join(OUTPUTS, "temp_rain_line.png")
    render_temp_rain_line(daily, temp_rain_path, title="温度与降雨量")
    merge_custom_layout(trend_path, calendar_path, warning_path, all_path)

    def to_md(date_str):
        if not date_str:
            return None
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%m-%d")

    start_md = to_md(best.get("start"))
    end_md   = to_md(best.get("end"))

    meta = {
        "start": start_md,
        "end": end_md,
        "start_full": best.get("start"),
        "end_full": best.get("end"),
        "variety": cn_variety,
        "area": area,
    }

    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists(trend_path):
            zf.write(trend_path, arcname="trend.png")
        if os.path.exists(temp_rain_path):
            zf.write(temp_rain_path, arcname="temp_rain_line.png")
        zf.writestr("meta.json", json.dumps(meta, ensure_ascii=False, indent=2))

    buf.seek(0)
    zip_b64 = base64.b64encode(buf.getvalue()).decode()

    return jsonify({
        "start": start_md,
        "end": end_md,
        "variety": cn_variety,
        "zip_base64": zip_b64
    })


if __name__ == "__main__":
    print("=== QWeather 环境检查 ===")
    print("HOST:", QWEATHER_HOST)
    print("KEY :", "(set)" if QWEATHER_KEY else "(missing)")
    print("固定城市ID:", DEFAULT_LOCATION_ID)
    print("Offseason forced:", should_force_offseason())
    app.run(host="0.0.0.0", port=25566, debug=True)