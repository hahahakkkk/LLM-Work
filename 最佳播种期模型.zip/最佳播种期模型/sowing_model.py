import os
import random
import calendar
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from sklearn.tree import DecisionTreeClassifier
from matplotlib import image as mimg
from matplotlib.font_manager import FontProperties
from PIL import Image

# ===== 中文字体设置（Linux/Win通用兜底）=====
import matplotlib
font_path = '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc'
if not os.path.exists(font_path):
    font_path = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
font_prop = FontProperties(fname=font_path)
matplotlib.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# 获取当前脚本所在目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ===== 1. 模型训练（特征 = 真实温度℃ + 干旱程度）=====
# 可替换为你自己的训练数据与模型；这里保留与原文件一致的简化示例
train_data = [
    [20, 1.0], [22, 2.0], [18, 3.0],
    [25, 4.0], [30, 3.0], [15, 3.0],
    [22, 5.0], [27, 1.0],
]
train_labels = ['Yes','Yes','Yes','Yes','No','No','No','No']
model = DecisionTreeClassifier()
model.fit(train_data, train_labels)

# ===== 2. 工具函数 =====
def date_to_day_of_year(date_str: str) -> int:
    return datetime.strptime(date_str, "%Y-%m-%d").timetuple().tm_yday

def is_within_time_range(day_of_year: int, variety: str) -> bool:
    # 品种经验期（保持你原值）
    ranges = {'A': (134, 150), 'B': (136, 155), 'C': (141, 161)}
    s, e = ranges.get(variety, (110, 130))
    return s <= day_of_year <= e

def is_within_time_range_area(day_of_year: int, variety_area: str) -> bool:
    # 区域经验期
    ranges = {
        'jiangxingzhuang': (148, 152),
        'gaojiajian':      (138, 142),
        'yuecha':          (140, 141),
        'lijiasi':         (140, 141),
        'houjiagou':       (150, 156),
        'sigou':           (138, 142),
        'yangjiagou':      (145, 146),
        'fengliangu':      (139, 141),
    }
    s, e = ranges.get(variety_area, (120, 170))
    return s <= day_of_year <= e

# ===== 3. 寻找最佳播种窗口（使用真实温度 temp）=====
def find_best_sowing_window(daily_data, variety, variety_area, year=2025):
    """
    模型预测 + 经验期：
    1) 窗口平均温度 + 最小降水量（或干旱等级）必须被模型预测为 Yes
    2) 窗口内每一天 (真实温度, 降水/干旱) 也必须逐日预测为 Yes
    """
    reasons = set()
    best_outside = None

    for window_size in (3, 4):
        for i in range(len(daily_data) - window_size + 1):
            win = daily_data[i:i + window_size]
            dates     = [d["date"] for d in win]
            temps     = [float(d["temp"]) for d in win]        # ✅ 真实温度
            rainfalls = [float(d["rainfall"]) for d in win]

            # 1) 整体窗口判断
            avg_temp = sum(temps) / window_size
            min_rain = min(rainfalls)
            doy      = date_to_day_of_year(dates[window_size // 2])

            if model.predict([[avg_temp, min_rain]])[0] != 'Yes':
                reasons.add("模型判断不适宜播种（整体平均不通过）")
                continue

            # 2) 逐日判断
            day_results = [model.predict([[t, r]])[0] for t, r in zip(temps, rainfalls)]
            if not all(res == 'Yes' for res in day_results):
                reasons.add("窗口内存在单日不适宜播种")
                continue

            # 3) 经验期判断
            within = is_within_time_range(doy, variety) and is_within_time_range_area(doy, variety_area)
            cand = {"start": dates[0], "end": dates[-1], "within_experience_range": within}

            if within:
                return cand
            if best_outside is None:
                best_outside = cand

    return best_outside or {"cannot_sow_reasons": sorted(reasons)}

# ===== 4. 预警图（按真实温度阈值判断）=====
def render_warning_image(daily_data, result, variety, output_path):
    name_map = {'A': "米脂1号", 'B': "米脂2号", 'C': "晋谷21号"}
    name = name_map.get(variety, variety)

    # 窗口期后一天检测
    next_day_data = None
    if "end" in result:
        end_idx = [i for i, d in enumerate(daily_data) if d["date"] == result["end"]]
        if end_idx and end_idx[0] + 1 < len(daily_data):
            next_day_data = daily_data[end_idx[0] + 1]

    # 默认状态与图标
    temp_warning = "温度适宜"
    humi_warning = "湿润"
    img_temp = os.path.join(BASE_DIR, "images", "温度适宜副本.png")
    img_humi = os.path.join(BASE_DIR, "images", "湿润.png")

    # ✅ 真实温度阈值（按需可微调）
    FROST_THRESH = 8.0   # < 8℃ 霜冻风险
    HOT_THRESH   = 22.0  # >= 22℃ 高温风险

    if next_day_data:
        t = float(next_day_data.get("temp", 999))
        if t < FROST_THRESH:
            temp_warning = "霜冻预警"
            img_temp = os.path.join(BASE_DIR, "images", "霜冻图标.png")
        elif t >= HOT_THRESH:
            temp_warning = "高温预警"
            img_temp = os.path.join(BASE_DIR, "images", "高温图标.png")

        if float(next_day_data.get("rainfall", 0)) == 5.0:
            humi_warning = "干旱预警"
            img_humi = os.path.join(BASE_DIR, "images", "干旱图标.png")

    # 绘制
    def short_date(d):
        return datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") if d else "-"

    start_md = short_date(result.get('start'))
    end_md   = short_date(result.get('end'))
    header_text = (
        f"基于本地气象与作物模型，\n"
        f"{name}的\n"
        f"最佳播种期为：{start_md} 至 {end_md}\n"
    )

    fig, ax = plt.subplots(figsize=(10, 8))
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.5, 0.65, header_text,
            transform=ax.transAxes, ha="center", va="center",
            fontsize=20, weight="bold", color="#2C3E50")

    img_t = mimg.imread(img_temp)
    img_h = mimg.imread(img_humi)
    ax.imshow(img_t, extent=[0.05, 0.35, 0.31, 0.61], transform=ax.transAxes)
    ax.imshow(img_h, extent=[0.5, 0.8, 0.31, 0.61], transform=ax.transAxes)

    ax.text(0.3, 0.45, f"{temp_warning}",
            transform=ax.transAxes, ha="left", va="center",
            fontsize=23, color="#E67E22", weight="bold")
    ax.text(0.75, 0.45, f"{humi_warning}",
            transform=ax.transAxes, ha="left", va="center",
            fontsize=23, color="#1ABC9C", weight="bold")

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print("输出图片已保存：", output_path)

# ===== 5. 趋势图（左轴：真实温度；右轴：干旱程度）=====
def render_summary_graph_with_window(daily_data, result, variety, output_path):
    dates     = [d['date'] for d in daily_data]
    temps     = [float(d['temp']) for d in daily_data]       # ✅ 真实温度
    rainfalls = [float(d['rainfall']) for d in daily_data]
    x = np.arange(len(dates))

    fig, ax1 = plt.subplots(figsize=(14, 5))
    ax2 = ax1.twinx()

    # 右轴：干旱程度柱
    ax2.bar(x - 0.2, rainfalls, width=0.4, label='熵情', color='#5DADE2', zorder=1)
    ax2.set_ylabel('熵情')

    # 左轴：温度曲线
    ax1.plot(x, temps, color='orange', label='气温(°C)', linewidth=2, zorder=3)
    ax1.set_ylabel('气温(°C)')

    ax1.set_xticks(x)
    ax1.set_xticklabels([datetime.strptime(d, "%Y-%m-%d").strftime("%m-%d") for d in dates],
                        rotation=45, ha='right')

    # 标注推荐窗口
    if 'start' in result and 'end' in result:
        si = dates.index(result['start'])
        ei = dates.index(result['end'])
        ax1.axvspan(si - 0.5, ei + 0.5, color='#2874A6', alpha=0.3, zorder=5, label='推荐播种窗口')

    # 合并图例
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='upper left', bbox_to_anchor=(1.1, 1))

    plt.tight_layout(rect=(0, 0, 0.8, 0.9))
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, bbox_inches='tight')
    plt.close()

# ===== 6. 中文月历图（保持不变）=====
def render_month_calendar(daily_data, result, output_path):
    import matplotlib.patches as patches
    dates = [datetime.strptime(d["date"], "%Y-%m-%d") for d in daily_data]
    year, month = dates[0].year, dates[0].month
    month_cal = calendar.Calendar(firstweekday=6).monthdayscalendar(year, month)

    sow_days = set()
    if "start" in result and "end" in result:
        sow_start = datetime.strptime(result["start"], "%Y-%m-%d")
        sow_end   = datetime.strptime(result["end"], "%Y-%m-%d")
        sow_days = {(sow_start + timedelta(days=i)).day
                    for i in range((sow_end - sow_start).days + 1)}

    fig, ax = plt.subplots(figsize=(10, 7))
    ax.set_facecolor("white")
    n_rows = len(month_cal) + 1
    ax.set_xlim(0, 7)
    ax.set_ylim(0, n_rows + 0.6)

    ax.text(0, n_rows + 0.3, f"{month}月",
            ha="left", va="center", fontsize=22, weight="bold", color="#2C3E50")
    legend_x = 7
    legend_y = n_rows + 0.3
    rect = patches.FancyBboxPatch(
        (legend_x - 2.5, legend_y - 0.25), 1.2, 0.5,
        boxstyle="round,pad=0.02,rounding_size=0.2",
        facecolor="#E8F6F3", edgecolor="#1ABC9C", linewidth=2
    )
    ax.add_patch(rect)
    ax.text(legend_x - 1.2, legend_y, "最佳播种窗口",
            ha="left", va="center", fontsize=14, color="#2C3E50")
    week_labels = ["日", "一", "二", "三", "四", "五", "六"]
    for col, label in enumerate(week_labels):
        ax.text(col + 0.5, n_rows - 0.3, label,
                ha="center", va="center",
                fontsize=20, weight="bold", color="#2C3E50")

    for row, week in enumerate(month_cal):
        y = len(month_cal) - row - 1
        sow_cols = [col for col, day in enumerate(week) if day in sow_days]
        if sow_cols:
            x_start, x_end = sow_cols[0], sow_cols[-1] + 1
            rect = patches.FancyBboxPatch(
                (x_start, y), x_end - x_start, 1,
                boxstyle="round,pad=0.02,rounding_size=0.28",
                facecolor="#E8F6F3", edgecolor="#1ABC9C",
                linewidth=2.5
            )
            ax.add_patch(rect)
        for col, day in enumerate(week):
            if day != 0:
                ax.text(col + 0.5, y + 0.5, str(day),
                        ha="center", va="center",
                        fontsize=20, weight="bold", color="#2C3E50")

    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()

# ===== 7. 合并三张图（保持不变）=====
def merge_custom_layout(trend_path, calendar_path, warning_path, output_path):
    """
    合并三张图：
    - 上：趋势图（缩放到和下方拼接图等宽）
    - 下：月历图 + 预警图（左右并排）
    """
    img_trend    = Image.open(trend_path)
    img_calendar = Image.open(calendar_path)
    img_warning  = Image.open(warning_path)

    target_height = min(img_calendar.height, img_warning.height)

    def resize_keep_ratio(img, target_h):
        w, h = img.size
        new_w = int(w * target_h / h)
        return img.resize((new_w, target_h))

    img_calendar = resize_keep_ratio(img_calendar, target_height)
    img_warning  = resize_keep_ratio(img_warning,  target_height)

    bottom_width  = img_calendar.width + img_warning.width
    bottom_height = target_height
    img_bottom = Image.new("RGB", (bottom_width, bottom_height), (255, 255, 255))
    img_bottom.paste(img_calendar, (0, 0))
    img_bottom.paste(img_warning, (img_calendar.width, 0))

    new_trend_height = int(img_trend.height * (bottom_width / img_trend.width))
    img_trend_resized = img_trend.resize((bottom_width, new_trend_height))

    total_width  = bottom_width
    total_height = img_trend_resized.height + img_bottom.height
    new_img = Image.new("RGB", (total_width, total_height), (255, 255, 255))
    new_img.paste(img_trend_resized, (0, 0))
    new_img.paste(img_bottom, (0, img_trend_resized.height))

    new_img.save(output_path)
    print(f"合并完成: {output_path}")
