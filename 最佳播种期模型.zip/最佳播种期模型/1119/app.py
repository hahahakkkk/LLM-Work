# app.py —— 非5/6月切换到内置数据 + 动态干旱规则 + QWeather简易鉴权（?key=）
import os
import traceback
import logging

import requests
import pandas as pd
import pymysql
from datetime import datetime
from flask import Flask, request, send_file, jsonify

# ====== 你的模型函数（已经去掉月历、预警、三图合并） ======
from sowing_model import (
    find_best_sowing_window,
    render_summary_graph_with_window,
    render_temp_mirror_bar,
    render_moisture_mirror_bar,
)

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUTS = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUTS, exist_ok=True)

# 品种映射（用于 /plot/info、/plot/trend_folder 等）
VARIETY_MAP = {
    "A": "米谷1号",
    "B": "米谷2号",
    "C": "晋谷21号",
}

# ---------- 全局异常输出 ----------
app.config["PROPAGATE_EXCEPTIONS"] = True


@app.errorhandler(Exception)
def _handle_any_error(e):
    logging.error("Unhandled error:", exc_info=True)
    print("".join(traceback.format_exception(type(e), e, e.__traceback__)))
    return jsonify(error=str(e)), 500


# ---------- MySQL（仅 /plot/all 用） ----------
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "123456",  # ← 按需修改
    "database": "best_sowing",
    "charset": "utf8mb4",
}
AREA_TABLE_MAP = {
    "jiangxingzhuang": "weather_jiangxingzhuang",
    "gaojiajian": "weather_gaojiajian",
    "yuecha": "weather_yuecha",
    "lijiasi": "weather_lijiasi",
    "houjiagou": "weather_houjiagou",
    "sigou": "weather_sigou",
    "yangjiagou": "weather_yangjiagou",
    "fengliangu": "weather_fengliangu",
}


def load_data_from_db(area: str, start_date: str = None, end_date: str = None):
    table = AREA_TABLE_MAP.get(area)
    if not table:
        raise ValueError(f"未知地区: {area}")
    conn = pymysql.connect(**DB_CONFIG)
    try:
        if start_date and end_date:
            q = f"""
                SELECT date, temp, rainfall
                FROM {table}
                WHERE date BETWEEN '{start_date}' AND '{end_date}'
                ORDER BY date ASC;
            """
        else:
            q = f"SELECT date, temp, rainfall FROM {table} ORDER BY date ASC;"
        df = pd.read_sql(q, conn)  # 长期建议用 SQLAlchemy，这里先按简易可用
    finally:
        conn.close()

    daily = []
    for _, row in df.iterrows():
        daily.append(
            {
                "date": str(row["date"]),
                "temp": float(row["temp"]),
                "rainfall": float(row["rainfall"]),  # 动态规则会覆盖
            }
        )
    return daily


# ---------- QWeather 简单鉴权 ----------
QWEATHER_HOST = os.getenv("QWEATHER_HOST", "devapi.qweather.com").strip()  # 用凭据页的 Host
QWEATHER_KEY = os.getenv("QWEATHER_KEY", "").strip()  # 用“凭据ID（API Key）”
QWEATHER_15D_URL = f"https://{QWEATHER_HOST}/v7/weather/15d"
QWEATHER_7D_URL = f"https://{QWEATHER_HOST}/v7/weather/7d"
DEFAULT_LOCATION_ID = "101110408"  # 无论传什么基地都映射到这个城市ID


def precip_to_dryness_level(precip_mm: float) -> int:
    # 1=湿润 ←→ 5=干旱；仅用于把“毫米”粗映到等级，之后会被动态规则覆盖
    if precip_mm >= 10:
        return 1
    if precip_mm >= 5:
        return 2
    if precip_mm >= 2:
        return 3
    if precip_mm >= 0.1:
        return 4
    return 5


def _call_qweather(url: str, loc: str, key: str):
    r = requests.get(url, params={"location": loc, "key": key}, timeout=10)
    print("QWeather URL:", r.url, "HTTP:", r.status_code)
    try:
        js = r.json()
    except Exception:
        js = {}
    return r.status_code, js, r.text


def fetch_future_from_qweather():
    if not QWEATHER_KEY:
        raise RuntimeError("未配置 QWEATHER_KEY（环境变量或在代码中写入）")
    loc = DEFAULT_LOCATION_ID

    code1, js1, text1 = _call_qweather(QWEATHER_15D_URL, loc, QWEATHER_KEY)
    if code1 == 200 and js1.get("code") == "200" and "daily" in js1:
        raw = js1["daily"]
    else:
        code2, js2, text2 = _call_qweather(QWEATHER_7D_URL, loc, QWEATHER_KEY)
        if not (code2 == 200 and js2.get("code") == "200" and "daily" in js2):
            raise RuntimeError(
                f"QWeather失败：15d {code1} {text1[:150]} | 7d {code2} {text2[:150]}"
            )
        raw = js2["daily"]

    out = []
    for d in raw:
        tmax, tmin = d.get("tempMax"), d.get("tempMin")
        if tmax is None and tmin is None:
            continue
        tmax = float(tmax) if tmax is not None else None
        tmin = float(tmin) if tmin is not None else None
        t_avg = (
            (tmax + tmin) / 2.0
            if (tmax is not None and tmin is not None)
            else (tmax or tmin)
        )

        precip = float(d.get("precip") or 0.0)  # 毫米
        dryness = precip_to_dryness_level(precip)  # 初步等级（随后会被动态规则覆盖）

        out.append(
            {
                "date": d.get("fxDate"),
                "temp": float(t_avg),
                "rainfall": float(dryness),
                "precip_mm": precip,
            }
        )
    return out


# ---------- 指定的“非 5/6 月”数据：按品种拆分 ----------


FORCED_DAILY_BY_VARIETY = {
    "A": [
        {"date": "2025-05-10", "temp": 12.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-11", "temp": 13.2, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-12", "temp": 17.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-13", "temp": 19.8, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-14", "temp": 18.3, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-15", "temp": 14.1, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-16", "temp": 22.4, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-17", "temp": 17.0, "precip_mm": 3.0, "rainfall": 3},
        {"date": "2025-05-18", "temp": 23.7, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-19", "temp": 23.9, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-20", "temp": 24.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-21", "temp": 28.2, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-22", "temp": 20.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-23", "temp": 21.8, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-24", "temp": 20.3, "precip_mm": 0.0, "rainfall": 0},
    ],
    "B": [
        # 这里写 B 品种的 15 天数据
        {"date": "2025-05-16", "temp": 22.4, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-17", "temp": 17.0, "precip_mm": 3.0, "rainfall": 3},
        {"date": "2025-05-18", "temp": 23.7, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-19", "temp": 23.9, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-20", "temp": 24.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-21", "temp": 28.2, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-22", "temp": 20.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-23", "temp": 21.8, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-24", "temp": 20.3, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-25", "temp": 26.3, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-26", "temp": 27.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-27", "temp": 24.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-28", "temp": 21.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-29", "temp": 18.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-30", "temp": 15.0, "precip_mm": 0.0, "rainfall": 0},
    ],
    "C": [
        # 这里写 C 品种的 15 天数据
        {"date": "2025-05-23", "temp": 21.8, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-24", "temp": 20.3, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-25", "temp": 26.3, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-26", "temp": 27.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-27", "temp": 24.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-28", "temp": 21.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-29", "temp": 18.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-30", "temp": 15.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-05-31", "temp": 16.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-06-1", "temp": 23.0, "precip_mm": 2.0, "rainfall": 0},
        {"date": "2025-06-2", "temp": 25.0, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-06-3", "temp": 24.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-06-4", "temp": 23.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-06-5", "temp": 22.5, "precip_mm": 0.0, "rainfall": 0},
        {"date": "2025-06-6", "temp": 21.8, "precip_mm": 0.0, "rainfall": 0},
    ],
}

def get_forced_daily(variety: str):
    """
    根据品种返回一份拷贝，避免修改原始常量。
    如果传了未知品种，就默认用 A 的数据。
    """
    base = FORCED_DAILY_BY_VARIETY.get(variety, FORCED_DAILY_BY_VARIETY["A"])
    return [dict(x) for x in base]



def should_force_offseason() -> bool:
    """当前月份不是 5 或 6 → 使用 FORCED_DAILY"""
    m = datetime.now().month
    return m not in (5, 6)


# ---------- 动态干旱规则 ----------
def apply_dynamic_drought(daily_data):
    """
    规则：
    - 第一天=3
    - 当天有雨(precip_mm>0 或 rainfall>0) → 5
    - 连续无雨每 3 天 干旱等级 -1，下限 1
    - 将最终等级写回 d["rainfall"]
    """
    drought = 3
    no_rain_count = 0
    for d in daily_data:
        precip_mm = float(d.get("precip_mm")) if d.get("precip_mm") is not None else None
        rained = (precip_mm is not None and precip_mm > 0) or (
            precip_mm is None and float(d.get("rainfall", 0)) > 0
        )

        if rained:
            drought = 5
            no_rain_count = 0
        else:
            no_rain_count += 1
            if no_rain_count >= 3:
                drought = max(1, drought - 1)
                no_rain_count = 0

        d["rainfall"] = float(drought)


# ---------- 健康检查 ----------
@app.get("/")
def index():
    return jsonify(
        {
            "ok": True,
            "message": "best_sowing API (real-temp) + dynamic drought + offseason fallback",
            "host": QWEATHER_HOST,
            "location_id": DEFAULT_LOCATION_ID,
            "offseason_forced": should_force_offseason(),
        }
    )


# ---------- 接口1：数据库日期段（只画趋势图，不再画月历/预警/合并） ----------
@app.post("/plot/all")
def plot_all():
    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")
    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = load_data_from_db(area, start_date, end_date)
        if not daily:
            return jsonify(error="数据库中该日期范围无数据"), 404

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path = os.path.join(OUTPUTS, "trend.png")
    render_summary_graph_with_window(daily, best, variety, trend_path)

    print(f"输出图片已保存：{trend_path}")
    return send_file(trend_path, mimetype="image/png")


# ---------- 接口2：未来天气（只画趋势图 + JSON，不再月历/预警/合并） ----------
@app.post("/plot/forecast")
def plot_forecast():
    """
    返回 JSON（start/end + 趋势图 base64）。
    """
    import base64

    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path = os.path.join(OUTPUTS, "trend.png")
    render_summary_graph_with_window(daily, best, variety, trend_path)

    print(f"输出图片已保存：{trend_path}")

    with open(trend_path, "rb") as f:
        img64 = base64.b64encode(f.read()).decode()

    return jsonify(
        {
            "start": best.get("start"),
            "end": best.get("end"),
            "image_base64": img64,
        }
    )


# ---------- 新接口：只返回趋势图 PNG（方便单独测） ----------
@app.post("/plot/trend")
def plot_trend_image():
    """
    返回趋势图（温度 + 墒情 + 推荐播种窗口）。
    请求 JSON：{ "variety": "A", "variety_area": "jiangxingzhuang" }
    """
    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    trend_path = os.path.join(OUTPUTS, "trend_only.png")
    render_summary_graph_with_window(daily, best, variety, trend_path)
    return send_file(trend_path, mimetype="image/png")


# ---------- 温度双向条形图 ----------
@app.post("/plot/temp_bar")
def plot_temp_bar():
    """
    返回“以 15°C 为 0”的温度双向条形图。
    请求 JSON：{ "variety": "A", "variety_area": "jiangxingzhuang" }
    """
    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    _ = find_best_sowing_window(daily, variety, area)

    temp_bar_path = os.path.join(OUTPUTS, "temp_bar_15.png")
    render_temp_mirror_bar(daily, variety, temp_bar_path)
    return send_file(temp_bar_path, mimetype="image/png")


# ---------- 墒情双向条形图 ----------
@app.post("/plot/moist_bar")
def plot_moist_bar():
    """
    返回墒情双向柱状图（PNG）
    """
    data = request.get_json(force=True) or {}
    area = data.get("variety_area") or data.get("area")
    variety = data.get("variety")
    if not area or not variety:
        return jsonify(error="必须提供 variety 与 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)

    moist_bar_path = os.path.join(OUTPUTS, "moist_bar.png")
    render_moisture_mirror_bar(daily, moist_bar_path)

    return send_file(moist_bar_path, mimetype="image/png")


# ---------- 只返回开始/结束日期 + 品种 ----------
@app.post("/plot/info")
def plot_info():
    """
    返回最佳播种期的开始/结束日期（MM-DD）和品种中文名。
    """
    from datetime import datetime as _dt

    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    def to_md(date_str):
        if not date_str:
            return None
        return _dt.strptime(date_str, "%Y-%m-%d").strftime("%m-%d")

    start_md = to_md(best.get("start"))
    end_md = to_md(best.get("end"))
    cn_variety = VARIETY_MAP.get(variety, variety)

    return jsonify(
        {
            "start": start_md,
            "end": end_md,
            "variety": cn_variety,
        }
    )


# ---------- 专家播种管理建议 ----------
@app.get("/expert/advice")
def expert_advice():
    advice_list = [
        "精细整地并保墒播种，做到上虚下实、地平土细利于齐苗。",
        "控制播量与密度，一般每亩0.5–1.0公斤，水肥好则稀、瘠薄地稍密。",
        "拌种或包衣处理，用杀菌剂和微量元素提高抗病性和出苗率。",
        "掌握播深2–3厘米，并尽量采用机械精量播种以保证均匀。",
        "播后及时镇压，稳墒提温促进整齐出苗。",
        "播后重视防鸟害和查苗补苗，并根据苗情适时追施少量速效氮肥。",
    ]
    return jsonify({"advice": advice_list})


# ---------- 新接口：趋势图 + 开始/结束 + 品种 → zip（等价“文件夹”） ----------
@app.post("/detect")
def plot_trend_folder():
    """
    返回 zip：
      - trend.png   ：趋势图
      - meta.json   ：开始/结束日期 + 品种名 + 原始日期
    """
    from datetime import datetime as _dt
    from io import BytesIO
    import zipfile, json

    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    best = find_best_sowing_window(daily, variety, area)

    folder = os.path.join(OUTPUTS, "trend_bundle")
    os.makedirs(folder, exist_ok=True)
    trend_path = os.path.join(folder, "trend.png")
    render_summary_graph_with_window(daily, best, variety, trend_path)

    def to_md(s):
        if not s:
            return None
        return _dt.strptime(s, "%Y-%m-%d").strftime("%m-%d")

    start_md = to_md(best.get("start"))
    end_md = to_md(best.get("end"))
    cn_variety = VARIETY_MAP.get(variety, variety)

    meta = {
        "start": start_md,
        "end": end_md,
        "start_full": best.get("start"),
        "end_full": best.get("end"),
        "variety": cn_variety,
        "area": area,
    }
    meta_path = os.path.join(folder, "meta.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    from io import BytesIO
    import zipfile

    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(trend_path, arcname="trend.png")
        zf.write(meta_path, arcname="meta.json")
    buf.seek(0)

    return send_file(
        buf,
        mimetype="application/zip",
        as_attachment=True,
        download_name="trend_folder.zip",
    )


# ---------- 新接口：温度 + 墒情 双向条形图 → 压缩包 ----------
@app.post("/getYiju")
def plot_bars_zip():
    """
    返回 zip：
      - temp_bar_15.png  ：温度双向条形图（基准 15°C）
      - moist_bar.png    ：墒情双向条形图（基准 2）
    """
    from io import BytesIO
    import zipfile

    data = request.get_json(force=True) or {}
    variety = data.get("variety")
    area = data.get("variety_area")

    if not variety or not area:
        return jsonify(error="请提供品种 variety 与 基地 variety_area"), 400

    if should_force_offseason():
        daily = get_forced_daily(variety)
    else:
        daily = fetch_future_from_qweather()
        if not daily:
            return jsonify(error="未来天气无可用数据"), 502

    apply_dynamic_drought(daily)
    _ = find_best_sowing_window(daily, variety, area)

    temp_bar_path = os.path.join(OUTPUTS, "temp_bar_15.png")
    moist_bar_path = os.path.join(OUTPUTS, "moist_bar.png")

    render_temp_mirror_bar(daily, variety, temp_bar_path)
    render_moisture_mirror_bar(daily, moist_bar_path)

    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists(temp_bar_path):
            zf.write(temp_bar_path, arcname="temp_bar_15.png")
        if os.path.exists(moist_bar_path):
            zf.write(moist_bar_path, arcname="moist_bar.png")
    buf.seek(0)

    return send_file(
        buf,
        mimetype="application/zip",
        as_attachment=True,
        download_name="bars_bundle.zip",
    )


if __name__ == "__main__":
    print("=== QWeather 环境检查 ===")
    print("HOST:", QWEATHER_HOST)
    print("KEY :", "(set)" if QWEATHER_KEY else "(missing)")
    print("固定城市ID:", DEFAULT_LOCATION_ID)
    print("Offseason forced:", should_force_offseason())
    app.run(host="0.0.0.0", port=25566, debug=True)
